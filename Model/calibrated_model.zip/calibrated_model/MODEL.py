from calibrated_model.parameters import *
from calibrated_model.global_vars import *
from calibrated_model.producer import *
from calibrated_model.movie import *
from calibrated_model.setup import *
from calibrated_model.go import *
from calibrated_model.conclusion import *

class model_cinema():
    def __init__(self, my_seed):
        
        random.seed(my_seed)
        np.random.seed(seed=my_seed)

        self.al = agents_list()
        self.par = parameters()
        self.gv = glob_vars(self.par)

    def run(self, rs, my_seed):
        
        random.seed(my_seed)
        np.random.seed(seed=my_seed)


        setup(self.par, self.gv, self.al, rs)

        for _ in range(self.par.max_time):
            go(self.par, self.gv, self.al)

        conclusion(self.par, self.gv, self.al)

        return self.gv


