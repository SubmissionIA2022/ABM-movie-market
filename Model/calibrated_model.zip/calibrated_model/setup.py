from calibrated_model.producer import *
import pandas as pd

def setup(par, gv, al, rs):

    #parameters for realistic producers
    db_prod = pd.read_excel("db_prod.xlsx")

    #create producers
    for i in range(par.n_producers):
        al.producers_list.append(producer.create_producers(1, par, al, i, db_prod, rs))

    #initialize calendar
    gv.on_release = [None] * par.max_time 
    gv.future_release = [None] * par.max_time 

        






