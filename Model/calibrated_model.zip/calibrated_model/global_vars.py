import numpy as np

class glob_vars:
    
    def __init__(self, par):

        self.year = 1 #number of the year
        self.month = 1 #number of the month
        self.week = 1 #number of the week (in the month)
        self.week_year = 1 #number of the week (in the year)
        self.t = 0 #time step of the simulation
        self.on_release = [None] * par.max_time #movies on release for each time step
        self.new_releases = [None] * par.max_time #movies on release for each time step
        self.future_release = [None] * par.max_time #movies scheduled for each time step
        self.ci = np.zeros(par.max_time) #competition index
        self.budg_ts = np.zeros(par.max_time) #budget of movies scheduled 
        self.budg_tm = np.zeros(par.max_time) #budget of top 10 movies scheduled 
        self.bo_ts = np.zeros(par.max_time) #time serie of box office results
        self.bo_tm = np.zeros(par.max_time) #time serie of box office results of the best 10 movies on the market (compare with real data)
        self.potential_audience = par.potential_audience #all the population that can attend to movies

        #for competition index
        self.budg_top10_norm_ts = np.zeros(par.max_time)
        self.bo_top10_norm_ts = np.zeros(par.max_time)
        self.release_norm_ts = np.zeros(par.max_time)
        self.expected_movies_or = np.zeros(par.max_time)

        #globals output
        self.movies_or_per_week = np.zeros(par.max_time)
        self.budget_movies_or_per_week = np.zeros(par.max_time)
        self.sum_attendance_ts = [] #time series of the total amount of audience called by the movies on release (if > avaiable, it is distributed)
        self.ci_compare = np.zeros(par.max_time) #competition index to use to compare in the output (not decision of agents)
        self.or_forecast_history = list(np.zeros(par.max_time)) #to save per each time step the number of mv OR estimated for the future

    def time_flow(self):
        self.t += 1
        self.week += 1
        self.week_year += 1
        if self.week > 5:
            self.week = 1
            self.month += 1
        elif self.week > 4 and not self.month in {3,6,9,12}:
            self.week = 1
            self.month += 1           
        if self.month > 12:
            self.week_year = 1
            self.month = 1
            self.year += 1


    def computeGlobals(self, al, par):

        movies_on_release = [mv for mv in al.movies_list if (mv.status == 2)] 
        for mv in movies_on_release:

            if self.on_release[self.t] == None:
                self.on_release[self.t] = [mv]
            else:
                self.on_release[self.t].append(mv)

            self.movies_or_per_week[self.t] += 1

            self.budget_movies_or_per_week[self.t] += mv.budget    

            self.bo_ts[self.t] += mv.box_office

            if mv.release_date == self.t:
                if self.new_releases[self.t] == None:
                    self.new_releases[self.t] = [mv]
                else:
                    self.new_releases[self.t].append(mv)

        tm = sorted(movies_on_release, key=lambda x: x.last_week_attendance, reverse=True)[:par.tm]

        for mv in tm:
            self.budg_tm[self.t] += mv.budget 
            self.bo_tm[self.t] += mv.last_week_attendance * par.ticket_cost 

        

            



    def competitionIndex(self, par, al):

        #before starting, compute the mean budget values to provide later to the competition index (so decisions are homogeneouse per time step)
        budg_ts_past = self.budg_ts[:self.t - 1] #budgets of period before this
        mean_budget = np.mean(budg_ts_past) #mean budget of periods before this

        budget_expected = np.mean([pr.rs_mean_budget for pr in al.producers_list])
        mean_expected = budget_expected * par.n_producers

        if mean_budget < mean_expected: #to avoid problem with division per infinite
            mean_budget = mean_expected


        for t in range(len(self.on_release)): #on_release and future_release are long as the simulation
            
            #if it is equal to time now, just assessing the real status on the released movies with box office
            if t == self.t:
                released_now = self.on_release[t] #movies on release on time t
                if released_now != None:
                    self.bo_ts[t] = sum(mv.box_office for mv in released_now)
                    self.budg_ts[t] = sum(mv.budget for mv in released_now)
                    bo_ts_pos = [bo for bo in self.bo_ts if ( bo > 0)]
                    bo_ts_mean = np.mean(bo_ts_pos) 
 
                    self.ci[t] = self.bo_ts[t] / bo_ts_mean
                else:
                    self.ci[t] = 1
                    self.bo_ts[t] = 0
                    self.budg_ts[t] = 0
                

            # if it is greater than time now (so, future) estimate the future from the budget
            if t > self.t:

                self.expected_movies_or[t] = 0

                budg_ts_past = self.budg_ts[:self.t - 1] #budgets of period before this
                mean_budget = np.mean(budg_ts_past) #mean budget of periods before this
                if mean_budget == 0: 
                    mean_budget = 550000

                self.budg_ts[t] = 0

                #a) movies on release before
                for t_old in range(t - par.ci_mean_release_time, t):
                    released_old_t = self.on_release[t_old] #movies on release the weeks before the one considered
                     
                    
                    if released_old_t != None:
                        for mv in released_old_t:
                            self.expected_movies_or[t] += 1
                            self.budg_ts[t] += mv.budget * ( (1 - par.ci_smooth) ** (t - t_old) ) #add to budget the smoothed "budget power"

                #b) movies scheduled just before (in the par.ci_mean_release_time period) or the same time
                for t_old in range(t - par.ci_mean_release_time, t + 1):
                    fr_old = self.future_release[t_old] #future release old
                    if fr_old != None: #to avoid compute before any movie is schedule for that time step
                        fr_bud_old = sum(mv.budget for mv in fr_old) #extract only the budget
                        #print(fr_bud_old)
                        self.budg_ts[t] += fr_bud_old * ( (1 - par.ci_smooth) ** (t - t_old) )
                        self.expected_movies_or[t] += len(fr_old)
                
                self.ci[t] =  self.budg_ts[t] / mean_budget 
            
        #last, save the expected_movies_or series per each time step
        self.or_forecast_history[self.t] = self.expected_movies_or
            
            





        








class agents_list:
    def __init__(self):
        self.producers_list = []
        self.bankroupt_producers_list = []
        self.movies_list = []



            