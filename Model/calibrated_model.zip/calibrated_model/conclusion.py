import numpy as np

def conclusion(par, gv, al):

    ts_release = np.zeros(gv.t + 1)
    for t in range(gv.t):
        if gv.on_release[t] != None:
            ts_release[t] = len(gv.on_release[t])
    
    ts_release_timeok = ts_release
    bo_tm_timeok = gv.bo_tm
    if par.max_time > 400 + 104:
        ts_release_timeok = ts_release[400:-104]
        bo_tm_timeok = gv.bo_tm[400:-104]
    max_release = max(ts_release_timeok)
    min_release = min(ts_release_timeok)
    max_bo_top10 = max(bo_tm_timeok)
    min_bo_top10 = min(bo_tm_timeok)

    for t in range(gv.t): 
        
        if (max_bo_top10 - min_bo_top10) != 0:
            gv.bo_top10_norm_ts[t] = (gv.bo_tm[t] - min_bo_top10) / (max_bo_top10 - min_bo_top10)

        if (max_release - min_release) != 0:
            gv.release_norm_ts[t] = (ts_release[t] - min_release) / (max_release - min_release)

        gv.ci_compare[t] = gv.bo_top10_norm_ts[t] - gv.release_norm_ts[t]  
    

    gv.on_release = gv.on_release[:(par.max_time - par.time_horizon_more)]
    gv.future_release = gv.future_release[:(par.max_time - par.time_horizon_more)]
    gv.ci = gv.ci[:(par.max_time - par.time_horizon_more)]
    gv.ci_compare = gv.ci_compare[:(par.max_time - par.time_horizon_more)]
    gv.bo_top10_norm_ts = gv.bo_top10_norm_ts[:(par.max_time - par.time_horizon_more)]
    gv.release_norm_ts = gv.release_norm_ts[:(par.max_time - par.time_horizon_more)]
    gv.budg_ts = gv.budg_ts[:(par.max_time - par.time_horizon_more)]
    gv.bo_ts = gv.bo_ts[:(par.max_time - par.time_horizon_more)]
    gv.bo_tm = gv.bo_tm[:(par.max_time - par.time_horizon_more)]
    gv.movies_or_per_week = gv.movies_or_per_week[:(par.max_time - par.time_horizon_more)]
    gv.budget_movies_or_per_week = gv.budget_movies_or_per_week[:(par.max_time - par.time_horizon_more)]  


    if par.max_time > 504:

        gv.ci_compare = gv.ci_compare[400:-104]
        gv.bo_top10_norm_ts = gv.bo_top10_norm_ts[400:-104]
        gv.release_norm_ts = gv.release_norm_ts[400:-104]

