import numpy as np

class movie:
    def __init__(self):
        self.who = 0 #number of the movie
        self.budget = 0
        self.box_office = 0
        self.ROI = 0
        self.status = 0 #0 = WIP, 1 = Release Scheduled, 2 = Released, 3 = Retired, 4 = Interrupted
        self.weeks_needed = 0
        self.completion = 0
        self.producer = None
        self.release_date = 0
    
        self.quality = 0 #how good is the movie, need to be zero here to work the movie creation
        self.pot_market = 0 #the total amount of people willing to attend the movie at each time step
        self.pot_market_init = 0 #the total amount of people willing to attend the movie at the time step of release
        self.total_attendance = 0
        self.week_released = 0
        
        #variables to track the dynamics of the movies
        self.weekly_attendance = []
        self.last_week_attendance = 0
        self.weekly_potential_market = []
        self.retire_index = 0
        self.retire_index_att = 0
        self.retire_index_mkt = 0
        self.ROI = 0

        #to track the retiring dynamics
        self.growing = True
        self.diff_attendance_mean = []

        #to track the scheduling decision --> THIS IS JUST FOR DEBUGGING
        self.ci_des = 0
        self.ci_choosed = 0
        self.ci_diff = 0 #it becomes a list in the scheduling part
        self.ci_diff_arr = [] #to save all the ci diff
        self.time_scheduled = 0
        self.time_created = 0


    def create_movie(self, producer, budget, par, gv):

        mv = movie()
        mv.budget = budget
        mv.producer = producer

        mv.weeks_needed = ( par.week_budget_m * mv.budget + par.week_budget_q ) * ( 0.5 + np.random.random())
    
        mv.quality = np.random.normal(1, 0.4)
        if mv.quality < 0:
            mv.quality = 0.5 + np.random.random()
        mv.pot_market = ( ( 1 - 0.541 ) * mv.quality + 0.541 * ( par.budget_success_m * mv.budget + par.budget_success_q ) ) * gv.potential_audience
        mv.pot_market_init = mv.pot_market
        mv.time_created = gv.t


        return mv
        
    def increaseCompletion(self, pr): #this is the movie shooting

        self.completion += 1 / (self.weeks_needed) #the value is the number of months passed every week on average
        if self.completion >= 1:
           self.completion = 1 
           pr.WIP.remove(self)
           pr.MTS.append(self)

    def releaseMovie(self, gv):

        if self.release_date == gv.t:
            self.status = 2

            self.producer.MS.remove(self) #remove from list of movie scheduled of the producer
            self.producer.MOR.append(self) #append tp list of movie on release of the producer

    def singleBoxOfficeResult(self, gv, par):

        self.last_week_attendance = par.mean_attendance * self.pot_market 

    def competitionBoxOfficeResult(self, gv, par, sum_attendance):

        # 1 - if necessary to spread the attendance and come back to the attendance do it
        if sum_attendance > gv.potential_audience * par.mean_attendance:
            self.last_week_attendance *= ( gv.potential_audience * par.mean_attendance ) / sum_attendance        

        # 2 - adapt the pot_market removing the attendance of this week
        self.pot_market -= self.last_week_attendance
           
        # 3 - generate income
        new_box_office = self.last_week_attendance * par.ticket_cost
        self.producer.wealth += new_box_office
        self.box_office += new_box_office
        
        # 4 - update variables to track results
        self.total_attendance += self.last_week_attendance
        self.week_released += 1
        self.weekly_attendance.append(self.last_week_attendance)
        self.weekly_potential_market.append(self.pot_market)

    def retireMovie(self, gv, par, list_attendance, list_attendance_budget):

        mean_attendance = np.mean(list_attendance)
        std_attendance = np.std(list_attendance)
        min_attendance = min(list_attendance)
        max_attendance = max(list_attendance)

        mean_attendance_bgt = np.mean(list_attendance_budget)
        min_attendance_bgt = min(list_attendance_budget)
        max_attendance_bgt = max(list_attendance_budget)

        #general rule: a movie can not be released more than one year
        if self.week_released > 51:
            retireMoviePractical(self)
        else:

            if self.week_released > 3: #if more than one movie AND more than three weeks of release --> possibility of retire

                self.growing = self.weekly_attendance[len(self.weekly_attendance) - 1] > self.weekly_attendance[len(self.weekly_attendance) - 2] 
                new_diff_attendance = self.last_week_attendance - ( mean_attendance + std_attendance )
                self.diff_attendance_mean.append(new_diff_attendance)
                last_box_office = self.last_week_attendance * par.ticket_cost
                #consider retire the movie only if conditions together
                if (( new_diff_attendance < 0 ) or (last_box_office < self.budget * 0.1)) and (not self.growing): 
                    
                    retire_index_att_1 = (self.last_week_attendance - min_attendance) / (max_attendance - min_attendance) #value of attendance normalize on the mean of the market
                    retire_index_att_2 = ((self.last_week_attendance / self.budget) - min_attendance_bgt) / (max_attendance_bgt - min_attendance_bgt) #value of attendance normalize on the mean of the market
                    self.retire_index_att = retire_index_att_1 * 0.5 + retire_index_att_2 * 0.5
                    self.retire_index_mkt = self.pot_market / self.pot_market_init #% of residual potential market 
                    time_index = ( 1 - ( self.week_released  / 52 ))
                    self.retire_index = ( self.retire_index_att * self.retire_index_mkt ) * max(time_index, 0)  #the sum is weighed for the weeks  
                    if self.retire_index < self.producer.retire_threshold:
                        retireMoviePractical(self)



def retireMoviePractical(mv):
    mv.producer.MOR.remove(mv)
    mv.producer.MR.append(mv)
    mv.status = 3

    #when retire, compute ROI
    mv.ROI = mv.box_office / mv.budget


            
            



