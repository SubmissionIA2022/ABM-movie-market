from calibrated_model.movie import *
from scipy.stats import powerlaw
import numpy as np
import random
import pandas as pd
from scipy.stats import gamma
from matplotlib import pyplot as plt

class producer:
    def __init__(self, par):
        self.who = 0 #number of the producer
        self.name = "" #name of the producer
        self.rs_budget = 0.5 + np.random.random() * 0.5 #risk sensitivity on the budget distributions of all the movies on release
        self.rs_mean_budget = 100000 + (900000 * np.random.random()) #if change here, change also the mean budget at line 125 of globals (in competition index)
        self.budget_gamma_a = 0 #parameter estimated budget distribution for sampling
        self.budget_gamma_b = 0 #parameter estimated budget distribution for sampling
        self.budget_gamma_s = 0 #parameter estimated budget distribution for sampling
        self.max_budget = 0 #parameter estimated budget distribution for sampling (for correction of max)
        self.type_distr_budget = "" #distribution shape of budget curve
        self.rs_release = np.random.normal(0,2) #risk sensitivity in the competition release
        self.frequency_release = 0#5 + np.random.randint(15) #max number of working in progress at the same time
        self.wealth = par.init_wealth #initial wealth of the producer
        self.WIP = [] #movies work in progress now
        self.MTS = [] #movies to schedule
        self.MS = [] #movies scheduled
        self.MOR = [] #movies on release
        self.MR = [] #movies retired
        self.retire_threshold = 0.5 #retire index value below which the movie is retired

        self.working = True #true if it is not bankroupt, false otherwise

    ############## SETUP ##############

    def create_producers(self, par, al, who, db_prod, rs):

        new_prod = producer(par)
        new_prod.who = who
        new_prod.budget_gamma_a = db_prod.a.iloc[who]
        new_prod.budget_gamma_b = db_prod.b.iloc[who]
        new_prod.budget_gamma_s = db_prod.s.iloc[who]
        new_prod.frequency_release = db_prod.num.iloc[who] / (20 * 52)
        new_prod.name = "***"
        new_prod.rs_mean_budget = db_prod.budg_mean.iloc[who]
        new_prod.max_budget = db_prod.max_budget.iloc[who]
        new_prod.type_distr_budget = db_prod.type.iloc[who]
        new_prod.rs_release = par.rs[who]

        return new_prod

    ############## GO ############## 

    #function for the decision about:
    # 1) if to release a new movie
    # 2) which budget to allocate
    def decideNewMovie(self, par, gv, al):

        for _ in range(np.random.poisson(lam=self.frequency_release)):
            i = 0
            new_budget = generate_budget(self)
            while new_budget > self.max_budget or new_budget < 1:
                new_budget = generate_budget(self)
                i += 1
                if i > 1000:
                    print(self.name)
                    break

            pr = self
            new_movie = movie.create_movie(self, pr, new_budget, par, gv)
            al.movies_list.append(new_movie)
            self.WIP.append(new_movie)

            #remove the budget from the wealth
            self.wealth -= new_budget


    def failingProcedure(self,gv,par, al):

        al.producers_list.remove(self)
        al.bankroupt_producers_list.append(self)
        self.working = False
        for mv in self.WIP:
            mv.status = 4            






    #function to decide the scheduling of a movie
    def scheduleReleaseRiskSensitive(self, mv, par, gv):

        #get the desidered competition index for the scheduled movie
        mv.ci_des = getCompetitionIndexDesidered(self, mv)
        mv.ci_diff = [] #empty list to collect differences of competition index desidered

        max_time_check = par.max_time
        if max_time_check > gv.t + 104:
            max_time_check = gv.t + 104
        avaiable_time_range = range(gv.t + 12, max_time_check)
        #check for each avaialable time if is empty, if it is not check the current competition index
        for t in avaiable_time_range:
            
            #if there is not movie schedule yet in the following time step, schedule there
            if gv.future_release[t] == None:
                gv.future_release[t] = [mv]
                scheduleMovieOperative(self, mv, t, gv) #function that change position in list and the status
                mv.ci_diff = 0
                mv.ci_diff_arr = [666]
                break


            else:
                #if there is movie, check the distance between estimation of competition index of that period 
                #and the one desidered found at the beginning of the function
                if gv.expected_movies_or[t] <= par.max_movie_per_week:
                    mv.ci_diff.append(abs(gv.ci[t] - mv.ci_des))
                else:
                    mv.ci_diff.append(1000) #high number so it won't be selected but it does not ruin code later with index

        
        if mv in self.MTS:
            
            #find the position of the minimum value of ci_diff, which is the point that fits better
            if len(mv.ci_diff) > 0 or gv.t + 12 < par.max_time:
                pos = mv.ci_diff.index(min(mv.ci_diff))
                mv.ci_choosed = gv.ci[pos]
                #find the correct time step from the range used for the previous cycle
                t_sched = avaiable_time_range[pos]
                #schedule the movie in that time
                scheduleMovieOperative(self, mv, t_sched, gv)
                mv.ci_diff_arr = mv.ci_diff #to save and show in the output (for debug)
                mv.ci_diff = min(mv.ci_diff) #to get the output of the difference


 

        

        







    









############## FUNCTIONS ##############


def fixDistribution(distr, multiplier):

    range_d = range(len(distr))

    #first, if some part of the distribution is infinite, just set to the one at its right
    for i in range_d:
        if distr[i] == float('inf'):
            distr[i] = distr[i + 1]

    fixing = 1 / distr.mean()
    for i in range_d:
        distr[i] *= ( fixing * multiplier )
    
    return distr

def newBudget(distr1, distr2, granularity, pr):
    
    
    # find max and min values of budget of movies
    distr_all = list(distr1) + list(distr2)
    max_ = max(distr_all)
    min_ = min(distr_all)
    int_ = ( max_ - min_ ) / granularity
    range_ = np.arange(min_, max_, int_)

    #for each distribution, set numerosity for each range
    distr1_fix = []
    distr2_fix = []          
    for r in range_:   
        distr1_fix.append(len(list(filter(lambda d: (d >= r) and (d <= r + int_) , distr1))))
        distr2_fix.append(len(list(filter(lambda d: (d >= r) and (d <= r + int_) , distr2))))
    
    #check the % difference (because numerosity could vary) of the belief from the reality
    diff = []
    for i in range(granularity):
        distr1_fix[i] = distr1_fix[i] / len(distr1)
        distr2_fix[i] = distr2_fix[i] / len(distr2)
        diff.append(distr1_fix[i] - distr2_fix[i])

    #the max difference is the poiunt in which the 2 distribution varies the most
    max_diff = diff.index(max(diff))
    new_budget = min_ + ( max_diff * int_ ) * (0.9 + 0.2 * np.random.random())
    
    return new_budget
    

def generate_budget(pr):

    if pr.type_distr_budget == "gamma":
        new_budget = gamma.rvs(pr.budget_gamma_a, pr.budget_gamma_b, scale=pr.budget_gamma_s)
    elif pr.type_distr_budget == "powerlaw":
        new_budget = powerlaw.rvs(pr.budget_gamma_a, loc = pr.budget_gamma_b, scale=pr.budget_gamma_s)
    else:
        new_budget = np.random.uniform(low=0, high=pr.max_budget, size=None)    
    return new_budget


def scheduleMovieOperative(pr, mv, t, gv):
    #append to future release
    if gv.future_release[t] != None:
        gv.future_release[t].append(mv)
    else:
        gv.future_release[t] = [mv]

    pr.MTS.remove(mv)
    pr.MS.append(mv)

    mv.status = 1
    mv.release_date = t

    mv.time_scheduled = gv.t

    

def getCompetitionIndexDesidered(pr, mv):

    budget_fixed = mv.budget / pr.rs_mean_budget #ratio (also > 1) between budget movie and preference of the producer
    
    potential_success = mv.quality * budget_fixed 

    ref_point_ps = 1 * 1 #reference point for potential success, 1 is the mean of fixed budget and 1 is the mean of quality
    ref_point_ci = 1 #the neutral ci is equal to 1 (the way was computed in the previous analysis)
    
    q = ref_point_ci - ref_point_ps * pr.rs_release #intercept
    ci_des = potential_success * pr.rs_release + q #desidered competition index for the movie

    return ci_des

