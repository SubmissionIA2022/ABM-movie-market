import numpy as np
import pandas as pd

class parameters:
    def __init__(self):

        #get the right number of producers
        db_prod = pd.read_excel("db_prod.xlsx")
    
        #general parameters of simulation
        self.time_horizon_more = 1 
        self.max_time = ( 15 + self.time_horizon_more) * 52 
        self.n_producers = len(db_prod)
        self.init_wealth = 100000000000

        #parameters of movie dynamics
        self.week_budget_m = 4.04680514636771e-07 
        self.week_budget_q = 4 
        self.ci_smooth = 0.1
        self.ci_mean_release_time = 3 

        #general parameters of the market
        self.potential_audience = 70000000 
        self.mean_attendance = 0.25 
        self.ticket_cost = 8 
        self.tm = 3
        self.budget_success_m = 1.989251e-09 
        self.budget_success_q = 6.278493e-03

        self.max_movie_per_week = 2000 
        self.max_movie_or_per_week = 50 
        self.rs = [ 2.70365819, -2.18553281,  5.93847953, -2.82880664, -1.35405772, -3.56014344, 1.64396673, -4.92856064, -1.64653325, -0.33724283,  5.60745691,  5.80876678, -1.05233691, -2.46438801, -1.86552516, -0.2830009,  -0.77628762,  4.09211012, 0.90573902, -1.10173608, -4.86364925,  3.11513182,  2.14279256, -0.31593494, -3.85474545,  4.98418201, -0.27131586]

        
