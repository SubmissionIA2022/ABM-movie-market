import random

def go(par, gv, al):

    # 0: shuffle producers list
    random.shuffle(al.producers_list)

    # 1: decide to do new movie and star production
    for pr in al.producers_list:
        pr.decideNewMovie(par, gv, al)

    # 2: movies increase completion rate
    for pr in al.producers_list:
        for w in pr.WIP:
            #increase completion and if complete move in the list of movies to schedule
            w.increaseCompletion(pr)

    # 3: schedule releases
    for pr in al.producers_list:
        for m in pr.MTS:
                pr.scheduleReleaseRiskSensitive(m, par, gv)

    # 4: release movies (at the scheduled time
    for pr in al.producers_list:
        for m in pr.MS:
            m.releaseMovie(gv)   

    # 5: compute box office results for the 
    sum_attendance = 0
    for pr in al.producers_list:
        for m in pr.MOR:
            m.singleBoxOfficeResult(gv, par)
            sum_attendance += m.last_week_attendance
    gv.sum_attendance_ts.append(sum_attendance)
    #another cycle because before all the movies need to have their "individual" results
    list_attendance = [] #compute mean box office movie this week for the step 7 (save time for 1 cycle)
    list_attendance_budget = []
    for pr in al.producers_list:
        for m in pr.MOR:
            m.competitionBoxOfficeResult(gv, par, sum_attendance) 
            list_attendance.append(m.last_week_attendance) #for step 7
            list_attendance_budget.append(m.last_week_attendance / m.budget)  #for step 7

    # 6: compute globals <-- here because for point 7 I need global results computed (don't want to do twice)
    gv.computeGlobals(al, par)
    gv.competitionIndex(par, al)

    # 7: retire movie when there are right conditions
    for pr in al.producers_list:
        for m in pr.MOR:
            m.retireMovie(gv, par, list_attendance, list_attendance_budget)

    # 8: if wealth < 0, fail:
    for pr in al.producers_list:
        if pr.wealth <= par.init_wealth * 0.01:
            pr.failingProcedure(gv,par, al)  







    

    # N: time flow

    gv.time_flow()


